let Districts  =[
    {name: 'Dhaka', upazilla: '20', },
    {name: 'Feni', upazilla: '6', },
    {name: 'CTG', upazilla: '23', },
    {name: 'Comilla', upazilla: '18', },
    {name: 'Noakahli', upazilla: '8', },
    {name: 'Chandpur', upazilla: '7', },
    {name: 'nator', upazilla: '4', },
    {name: 'BBaria', upazilla: '5', },
    {name: 'Bogra', upazilla: '5', },
    {name: 'Gazipur', upazilla: '16', },
]

let upazilla  =[
    {name: 'Chhagalnaiya', Dist: 'Feni', },
    {name: 'Feni Sadar', Dist: 'Feni', },
    {name: '14Gram', Dist: 'Cumilla', },
    {name: 'Savar', Dist: 'Dhaka', },
    {name: 'Damrai', Dist: 'Dhaka', },
    {name: 'Gozaria', Dist: 'Munshigonj', },
 
]



export{Districts, upazilla}
